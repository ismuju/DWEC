addEventListener('DOMContentLoaded',function(){

  var enlace = document.getElementsByTagName("a")[0];

  enlace.addEventListener('click',mostrarHorario);

  function mostrarHorario(e){
    e.preventDefault();
    var mens = document.getElementsByClassName('explicaHorario')[0];
    mens.style.display = "block";
  }


  selector.addEventListener('change',equipacion);

  function equipacion(e){
    var imgNombre = selector.value;
    var imagen = document.getElementsByTagName("img")[0];

    if (imgNombre == 0) {
      imagen.src =  "salareuniones.png";
    }else {
      imagen.src = "sala"+imgNombre + ".png";
    }
  }

  //Cuando se envíe el formulario, se ejecuta la función
  document.getElementById('formulario').addEventListener('submit',function(e){
    //Impido que se envíe el formulario hasta saber si todo va bien
    e.preventDefault();


    //Listado de errores
    var errList ="";

    //Ret es lo que devolverá return cuando acabe la validación
    var ret = true;



    //validamos el email:
    var email = document.getElementsByName("email")[0].value;
    if ( !(/^\w+([\.\-\+]?\w+)*@\w+([\.\-]?\w+)*(\.\w+)+$/.test(email)) ){
      errList += "El email es incorrecto. <br/>";
      ret = false;
    }

    var departamento = document.getElementsByName('depart')[0].value;
    if (departamento == null || departamento.length == 0 || !(/^\S+[\s+\S+]+$/.test(departamento))){
      errList += "Hay un error en el departamento. <br/>";
      ret = false;
    }

    var asis = document.getElementsByName('asistentes')[0].value;
    if (asis == null || asis.length == 0 || !(/^\d{1,2}$/.test(asis))){
      errList += "Error en Nº de asistentes. <br/>";
      ret = false;
    }



    //validamos la fecha:
    var fech = (document.getElementsByName('fecha')[0].value).split('-');
    var ano=fech[0];
    var mes=fech[1];// de 0 a 11
    var dia=fech[2];// 1 a 31

    var nf= new Date(ano,(mes - 1),dia);
    var hoy = new Date();

    if ( isNaN(nf) || dia < 1 || dia > 31 || mes < 1 || mes > 12 || ano < 0 || ano < hoy.getFullYear()){
      errList += "La fecha es errónea <br/>"
      ret = false;
    }


    //VALIDAMOS HORA
    var hor = document.getElementsByName('hora')[0].value;
    if (hor > 8 && hor < 21) {
      if (hor == null || hor.length == 0 || !(/^\d{2}$/.test(hor))){
            errList += "Error en la hora de reserva. <br/>";
            ret = false;
      }
    }else {
      errList += "Error en la hora de reserva. <br/>";
      ret = false;

    }



    //COMPROBAMOS SI LA RESERVA ES EN EL FUTURO
    var dat = (document.getElementsByName('fecha')[0].value).split('-');

    var diaMili=1000*60*60*24;

    var horaMili = (hor*1000*60); //HORA EN MILISEGUNDOS


    var fec = new Date(dat);

    //SACO LAS FECHAS EN MILISEGUNDOS
    var dia1 = Date.parse(fec) + horaMili;

    var resul = (dia1 - Date.now());
    var diaSecun1 = resul/diaMili;

    if (diaSecun1 < 0) {
      errList += "La hora de reserva debe ser en el futuro. <br/>";
      ret = false;
    }


    //SI HA ACEPTADO EL CHECK
    if (! cond.checked){
      ret = false;
      errList += "Se tiene que comprometer a liberar la sala en caso de cancelación. <br/>";
    }




    if (ret){
      //Si estoy aquí, voy a enviar el formulario y todo ha ido bien
      //Justo antes de enviar el formulario, puedes deshabilitar el botón de Envío para que no exista rebote
      document.getElementById("enviar").value = "Enviando...";
      document.getElementById("enviar").disabled = true;

      window.localStorage.Email=email;

      window.localStorage.FechaReserva=fecha.value;

      window.localStorage.HoraReserva=hora.value;


      if (selector.value != 0) {
        window.localStorage.Sala=selector.value;
      }

      //Si todo va bien envío el formulario
      document.forms[0].submit();
    }else{
      errores.style.color="red";
      errores.innerHTML = errList;
    }

  });








});
