addEventListener('DOMContentLoaded',function(){

  var email = window.localStorage.Email;
  var fecha = window.localStorage.FechaReserva;
  var hora = window.localStorage.HoraReserva;

  var fech = fecha.split('-');
  var ano=fech[0];
  var mes=fech[1];// de 0 a 11
  var dia=fech[2];// 1 a 31


  var men = "Su reserva se ha realizado correctamente. Recuerde que el día <b>" + dia + "</b> del mes <b>" + mes + "</b> del año <b>" + ano + "</b> a las <b>" + hora + ":00</b> tienes la reserva.<br>";
  men+= "En el correo <b>" + email + "</b> tiene que confirmar la reserva<br>";

  if (window.localStorage.Sala) {
    var sala = window.localStorage.Sala;
    men+= "Sala reservada: <b>" + sala+"</b>";
  }

  mensaje.innerHTML= men;

});
